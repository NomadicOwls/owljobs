"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Search, MapPin, ArrowRight } from "lucide-react"

export function Hero() {
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState("")
  const [locationQuery, setLocationQuery] = useState("")

  const handleSearch = () => {
    const params = new URLSearchParams()
    if (searchQuery) params.set("q", searchQuery)
    if (locationQuery) params.set("location", locationQuery)
    router.push(`/jobs${params.toString() ? `?${params.toString()}` : ""}`)
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSearch()
    }
  }

  const handlePopularSearch = (term: string) => {
    router.push(`/jobs?q=${encodeURIComponent(term)}`)
  }

  return (
    <section className="relative overflow-hidden pt-32 pb-20 sm:pt-40 sm:pb-32">
      {/* Glow effect */}
      <div className="pointer-events-none absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2">
        <div className="h-[600px] w-[600px] rounded-full bg-accent/30 blur-[120px]" />
      </div>

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-4xl text-center">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-border bg-secondary px-4 py-1.5 text-sm text-muted-foreground">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-accent opacity-75" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-accent" />
            </span>
            2,500+ AI jobs available
          </div>

          <h1 className="text-balance text-4xl font-bold tracking-tight text-foreground sm:text-6xl lg:text-7xl">
            Find your next role
            <br />
            <span className="text-accent">in AI.</span>
          </h1>

          <p className="mx-auto mt-6 max-w-2xl text-pretty text-lg text-muted-foreground sm:text-xl">
            The #1 job board for machine learning engineers, prompt engineers, AI researchers, and everyone building the future of artificial intelligence.
          </p>

          {/* Search Bar */}
          <div className="mx-auto mt-10 max-w-3xl">
            <div className="flex flex-col gap-3 rounded-2xl border border-border bg-card p-2 sm:flex-row sm:items-center">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
                <Input
                  type="text"
                  placeholder="Job title, skill, or company"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={handleKeyDown}
                  className="h-12 border-0 bg-transparent pl-10 text-foreground placeholder:text-muted-foreground focus-visible:ring-0"
                />
              </div>
              <div className="relative flex-1 border-t border-border pt-3 sm:border-l sm:border-t-0 sm:pt-0 sm:pl-3">
                <MapPin className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground sm:left-6" />
                <Input
                  type="text"
                  placeholder="Location or Remote"
                  value={locationQuery}
                  onChange={(e) => setLocationQuery(e.target.value)}
                  onKeyDown={handleKeyDown}
                  className="h-12 border-0 bg-transparent pl-10 text-foreground placeholder:text-muted-foreground focus-visible:ring-0"
                />
              </div>
              <Button 
                size="lg" 
                className="h-12 gap-2 bg-primary px-6 text-primary-foreground hover:bg-primary/90"
                onClick={handleSearch}
              >
                Search Jobs
                <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Popular searches */}
          <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
            <span className="text-sm text-muted-foreground">Popular:</span>
            {["Prompt Engineer", "ML Engineer", "AI Researcher", "LLM Developer"].map((term) => (
              <button
                key={term}
                onClick={() => handlePopularSearch(term)}
                className="rounded-full border border-border bg-secondary px-3 py-1 text-sm text-foreground transition-colors hover:border-accent hover:text-accent"
              >
                {term}
              </button>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
