export function Companies() {
  const companies = [
    { name: "OpenAI", logo: "🧠" },
    { name: "Anthropic", logo: "🤖" },
    { name: "DeepMind", logo: "🔬" },
    { name: "Cohere", logo: "💡" },
    { name: "Hugging Face", logo: "🤗" },
    { name: "Scale AI", logo: "📊" },
    { name: "Stability AI", logo: "🎨" },
    { name: "Midjourney", logo: "✨" },
  ]

  return (
    <section id="companies" className="border-y border-border bg-card/30 py-12">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <p className="mb-8 text-center text-sm font-medium uppercase tracking-widest text-muted-foreground">
          Trusted by leading AI companies
        </p>

        <div className="flex flex-wrap items-center justify-center gap-8 sm:gap-12 lg:gap-16">
          {companies.map((company) => (
            <div
              key={company.name}
              className="flex items-center gap-2 text-muted-foreground transition-colors hover:text-foreground"
            >
              <span className="text-2xl">{company.logo}</span>
              <span className="font-medium">{company.name}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
