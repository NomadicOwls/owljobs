"use client"

import { useState } from "react"
import { JobCard } from "@/components/job-card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { jobs } from "@/lib/jobs-data"

const categories = ["All", "Engineering", "Research", "Product", "Design"]

export function JobListings() {
  const [selectedCategory, setSelectedCategory] = useState("All")

  const filteredJobs =
    selectedCategory === "All"
      ? jobs
      : jobs.filter((job) => job.category === selectedCategory)

  return (
    <section id="jobs" className="py-16 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h2 className="text-2xl font-bold text-foreground sm:text-3xl">
              Latest AI Jobs
            </h2>
            <p className="mt-2 text-muted-foreground">
              Explore opportunities at companies shaping the future of AI
            </p>
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "secondary"}
                size="sm"
                onClick={() => setSelectedCategory(category)}
                className={
                  selectedCategory === category
                    ? "bg-accent text-accent-foreground hover:bg-accent/90"
                    : "bg-secondary text-muted-foreground hover:bg-secondary/80 hover:text-foreground"
                }
              >
                {category}
              </Button>
            ))}
          </div>
        </div>

        {/* Jobs Grid */}
        <div className="mt-8 grid gap-4">
          {filteredJobs.map((job) => (
            <JobCard key={job.id} {...job} />
          ))}
        </div>

        {/* Load More */}
        <div className="mt-10 text-center">
          <Button
            variant="outline"
            size="lg"
            className="border-border bg-transparent text-foreground hover:bg-secondary"
          >
            View All Jobs
            <Badge variant="secondary" className="ml-2 bg-secondary text-muted-foreground">
              2,500+
            </Badge>
          </Button>
        </div>
      </div>
    </section>
  )
}
