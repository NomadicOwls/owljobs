import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { MapPin, Clock, DollarSign, Building2 } from "lucide-react"

interface JobCardProps {
  id: number
  title: string
  company: string
  location: string
  salary: string
  type: string
  tags: string[]
  logo: string
  postedAt: string
  featured?: boolean
}

export function JobCard({
  id,
  title,
  company,
  location,
  salary,
  type,
  tags,
  logo,
  postedAt,
  featured = false,
}: JobCardProps) {
  return (
    <Link href={`/jobs/${id}`}>
      <div
        className={`group relative rounded-xl border p-5 transition-all hover:border-accent/50 hover:bg-card/80 ${
          featured ? "border-accent/30 bg-card" : "border-border bg-card/50"
        }`}
      >
      {featured && (
        <div className="absolute -top-2.5 left-4">
          <Badge className="bg-accent text-accent-foreground">Featured</Badge>
        </div>
      )}

      <div className="flex gap-4">
        {/* Company Logo */}
        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg border border-border bg-secondary text-xl">
          {logo}
        </div>

        <div className="min-w-0 flex-1">
          {/* Header */}
          <div className="flex flex-wrap items-start justify-between gap-2">
            <div>
              <h3 className="font-semibold text-foreground transition-colors group-hover:text-accent">
                {title}
              </h3>
              <div className="mt-1 flex items-center gap-1.5 text-sm text-muted-foreground">
                <Building2 className="h-3.5 w-3.5" />
                {company}
              </div>
            </div>
            <span className="text-xs text-muted-foreground">{postedAt}</span>
          </div>

          {/* Details */}
          <div className="mt-3 flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
            <span className="flex items-center gap-1">
              <MapPin className="h-3.5 w-3.5" />
              {location}
            </span>
            <span className="flex items-center gap-1">
              <DollarSign className="h-3.5 w-3.5" />
              {salary}
            </span>
            <span className="flex items-center gap-1">
              <Clock className="h-3.5 w-3.5" />
              {type}
            </span>
          </div>

          {/* Tags */}
          <div className="mt-3 flex flex-wrap gap-1.5">
            {tags.map((tag) => (
              <Badge
                key={tag}
                variant="secondary"
                className="bg-secondary text-muted-foreground hover:text-foreground"
              >
                {tag}
              </Badge>
            ))}
          </div>
        </div>
      </div>
      </div>
    </Link>
  )
}
