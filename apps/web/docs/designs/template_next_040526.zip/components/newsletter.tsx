"use client"

import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Mail, ArrowRight } from "lucide-react"

export function Newsletter() {
  return (
    <section className="py-16 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="relative overflow-hidden rounded-2xl border border-border bg-card p-8 sm:p-12 lg:p-16">
          {/* Glow effect */}
          <div className="pointer-events-none absolute -top-24 -right-24">
            <div className="h-64 w-64 rounded-full bg-accent/20 blur-[100px]" />
          </div>

          <div className="relative mx-auto max-w-2xl text-center">
            <div className="mx-auto mb-6 flex h-14 w-14 items-center justify-center rounded-full bg-accent/10">
              <Mail className="h-6 w-6 text-accent" />
            </div>

            <h2 className="text-2xl font-bold text-foreground sm:text-3xl">
              Get AI jobs in your inbox
            </h2>
            <p className="mx-auto mt-4 max-w-lg text-muted-foreground">
              Subscribe to our weekly newsletter and never miss a new opportunity. Join 15,000+ AI professionals.
            </p>

            <form className="mt-8 flex flex-col gap-3 sm:flex-row sm:justify-center">
              <Input
                type="email"
                placeholder="Enter your email"
                className="h-12 w-full border-border bg-background text-foreground placeholder:text-muted-foreground sm:w-72"
              />
              <Button
                type="submit"
                size="lg"
                className="h-12 gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
              >
                Subscribe
                <ArrowRight className="h-4 w-4" />
              </Button>
            </form>

            <p className="mt-4 text-xs text-muted-foreground">
              No spam, unsubscribe anytime. By subscribing you agree to our Privacy Policy.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
