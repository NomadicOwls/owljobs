import { Header } from "@/components/header"
import { Hero } from "@/components/hero"
import { Companies } from "@/components/companies"
import { JobListings } from "@/components/job-listings"
import { Stats } from "@/components/stats"
import { Newsletter } from "@/components/newsletter"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <Hero />
        <Companies />
        <Stats />
        <JobListings />
        <Newsletter />
      </main>
      <Footer />
    </div>
  )
}
