"use client"

import { useState, useMemo } from "react"
import Link from "next/link"
import { useSearchParams } from "next/navigation"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { jobs, type Job } from "@/lib/jobs-data"
import {
  Search,
  MapPin,
  SlidersHorizontal,
  X,
  Building2,
  Clock,
  DollarSign,
  Briefcase,
  ChevronDown,
  ChevronUp,
} from "lucide-react"

const jobTypes = ["Full-time", "Part-time", "Contract", "Internship"]
const experienceLevels = ["Entry Level", "Mid Level", "Senior", "Lead", "Executive"]
const categories = ["Engineering", "Research", "Product", "Design", "Operations"]
const locations = ["Remote", "San Francisco, CA", "New York, NY", "London, UK", "Toronto, CA"]

export default function JobsPage() {
  const searchParams = useSearchParams()
  const initialQuery = searchParams.get("q") || ""
  const initialLocation = searchParams.get("location") || ""

  const [searchQuery, setSearchQuery] = useState(initialQuery)
  const [locationQuery, setLocationQuery] = useState(initialLocation)
  const [selectedTypes, setSelectedTypes] = useState<string[]>([])
  const [selectedCategories, setSelectedCategories] = useState<string[]>([])
  const [selectedLocations, setSelectedLocations] = useState<string[]>([])
  const [showFilters, setShowFilters] = useState(false)
  const [expandedSections, setExpandedSections] = useState({
    type: true,
    category: true,
    location: true,
  })

  const toggleSection = (section: keyof typeof expandedSections) => {
    setExpandedSections((prev) => ({ ...prev, [section]: !prev[section] }))
  }

  const toggleFilter = (
    value: string,
    selected: string[],
    setSelected: React.Dispatch<React.SetStateAction<string[]>>
  ) => {
    setSelected((prev) =>
      prev.includes(value) ? prev.filter((v) => v !== value) : [...prev, value]
    )
  }

  const clearAllFilters = () => {
    setSearchQuery("")
    setLocationQuery("")
    setSelectedTypes([])
    setSelectedCategories([])
    setSelectedLocations([])
  }

  const filteredJobs = useMemo(() => {
    return jobs.filter((job) => {
      const matchesSearch =
        searchQuery === "" ||
        job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        job.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
        job.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase()))

      const matchesLocation =
        locationQuery === "" ||
        job.location.toLowerCase().includes(locationQuery.toLowerCase())

      const matchesType = selectedTypes.length === 0 || selectedTypes.includes(job.type)

      const matchesCategory =
        selectedCategories.length === 0 || selectedCategories.includes(job.category)

      const matchesSelectedLocation =
        selectedLocations.length === 0 ||
        selectedLocations.some((loc) =>
          job.location.toLowerCase().includes(loc.toLowerCase())
        )

      return (
        matchesSearch &&
        matchesLocation &&
        matchesType &&
        matchesCategory &&
        matchesSelectedLocation
      )
    })
  }, [searchQuery, locationQuery, selectedTypes, selectedCategories, selectedLocations])

  const activeFilterCount =
    selectedTypes.length + selectedCategories.length + selectedLocations.length

  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Search Header */}
      <div className="border-b border-border bg-card/50">
        <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
          <h1 className="mb-6 text-3xl font-bold text-foreground">Find AI Jobs</h1>
          <div className="flex flex-col gap-3 sm:flex-row">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search by title, company, or skill..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="h-12 border-border bg-background pl-10"
              />
            </div>
            <div className="relative flex-1 sm:max-w-xs">
              <MapPin className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Location or Remote"
                value={locationQuery}
                onChange={(e) => setLocationQuery(e.target.value)}
                className="h-12 border-border bg-background pl-10"
              />
            </div>
            <Button
              variant="outline"
              className="h-12 gap-2 sm:hidden"
              onClick={() => setShowFilters(!showFilters)}
            >
              <SlidersHorizontal className="h-4 w-4" />
              Filters
              {activeFilterCount > 0 && (
                <Badge variant="secondary" className="ml-1">
                  {activeFilterCount}
                </Badge>
              )}
            </Button>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="flex gap-8">
          {/* Sidebar Filters - Desktop */}
          <aside className="hidden w-64 shrink-0 lg:block">
            <div className="sticky top-24 space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold text-foreground">Filters</h2>
                {activeFilterCount > 0 && (
                  <button
                    onClick={clearAllFilters}
                    className="text-sm text-accent hover:underline"
                  >
                    Clear all
                  </button>
                )}
              </div>

              {/* Job Type */}
              <div className="space-y-3">
                <button
                  onClick={() => toggleSection("type")}
                  className="flex w-full items-center justify-between text-sm font-medium text-foreground"
                >
                  Job Type
                  {expandedSections.type ? (
                    <ChevronUp className="h-4 w-4" />
                  ) : (
                    <ChevronDown className="h-4 w-4" />
                  )}
                </button>
                {expandedSections.type && (
                  <div className="space-y-2">
                    {jobTypes.map((type) => (
                      <label
                        key={type}
                        className="flex cursor-pointer items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
                      >
                        <Checkbox
                          checked={selectedTypes.includes(type)}
                          onCheckedChange={() =>
                            toggleFilter(type, selectedTypes, setSelectedTypes)
                          }
                        />
                        {type}
                      </label>
                    ))}
                  </div>
                )}
              </div>

              {/* Category */}
              <div className="space-y-3">
                <button
                  onClick={() => toggleSection("category")}
                  className="flex w-full items-center justify-between text-sm font-medium text-foreground"
                >
                  Category
                  {expandedSections.category ? (
                    <ChevronUp className="h-4 w-4" />
                  ) : (
                    <ChevronDown className="h-4 w-4" />
                  )}
                </button>
                {expandedSections.category && (
                  <div className="space-y-2">
                    {categories.map((category) => (
                      <label
                        key={category}
                        className="flex cursor-pointer items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
                      >
                        <Checkbox
                          checked={selectedCategories.includes(category)}
                          onCheckedChange={() =>
                            toggleFilter(category, selectedCategories, setSelectedCategories)
                          }
                        />
                        {category}
                      </label>
                    ))}
                  </div>
                )}
              </div>

              {/* Location */}
              <div className="space-y-3">
                <button
                  onClick={() => toggleSection("location")}
                  className="flex w-full items-center justify-between text-sm font-medium text-foreground"
                >
                  Location
                  {expandedSections.location ? (
                    <ChevronUp className="h-4 w-4" />
                  ) : (
                    <ChevronDown className="h-4 w-4" />
                  )}
                </button>
                {expandedSections.location && (
                  <div className="space-y-2">
                    {locations.map((location) => (
                      <label
                        key={location}
                        className="flex cursor-pointer items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
                      >
                        <Checkbox
                          checked={selectedLocations.includes(location)}
                          onCheckedChange={() =>
                            toggleFilter(location, selectedLocations, setSelectedLocations)
                          }
                        />
                        {location}
                      </label>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </aside>

          {/* Mobile Filters */}
          {showFilters && (
            <div className="fixed inset-0 z-50 bg-background p-4 lg:hidden">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold">Filters</h2>
                <Button variant="ghost" size="icon" onClick={() => setShowFilters(false)}>
                  <X className="h-5 w-5" />
                </Button>
              </div>

              <div className="space-y-6 overflow-y-auto pb-24">
                {/* Job Type */}
                <div className="space-y-3">
                  <h3 className="text-sm font-medium text-foreground">Job Type</h3>
                  <div className="space-y-2">
                    {jobTypes.map((type) => (
                      <label
                        key={type}
                        className="flex cursor-pointer items-center gap-2 text-sm text-muted-foreground"
                      >
                        <Checkbox
                          checked={selectedTypes.includes(type)}
                          onCheckedChange={() =>
                            toggleFilter(type, selectedTypes, setSelectedTypes)
                          }
                        />
                        {type}
                      </label>
                    ))}
                  </div>
                </div>

                {/* Category */}
                <div className="space-y-3">
                  <h3 className="text-sm font-medium text-foreground">Category</h3>
                  <div className="space-y-2">
                    {categories.map((category) => (
                      <label
                        key={category}
                        className="flex cursor-pointer items-center gap-2 text-sm text-muted-foreground"
                      >
                        <Checkbox
                          checked={selectedCategories.includes(category)}
                          onCheckedChange={() =>
                            toggleFilter(category, selectedCategories, setSelectedCategories)
                          }
                        />
                        {category}
                      </label>
                    ))}
                  </div>
                </div>

                {/* Location */}
                <div className="space-y-3">
                  <h3 className="text-sm font-medium text-foreground">Location</h3>
                  <div className="space-y-2">
                    {locations.map((location) => (
                      <label
                        key={location}
                        className="flex cursor-pointer items-center gap-2 text-sm text-muted-foreground"
                      >
                        <Checkbox
                          checked={selectedLocations.includes(location)}
                          onCheckedChange={() =>
                            toggleFilter(location, selectedLocations, setSelectedLocations)
                          }
                        />
                        {location}
                      </label>
                    ))}
                  </div>
                </div>
              </div>

              <div className="fixed bottom-0 left-0 right-0 border-t border-border bg-background p-4">
                <div className="flex gap-3">
                  <Button variant="outline" className="flex-1" onClick={clearAllFilters}>
                    Clear All
                  </Button>
                  <Button className="flex-1" onClick={() => setShowFilters(false)}>
                    Show {filteredJobs.length} Jobs
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Job Listings */}
          <div className="flex-1">
            <div className="mb-6 flex items-center justify-between">
              <p className="text-sm text-muted-foreground">
                <span className="font-medium text-foreground">{filteredJobs.length}</span> jobs
                found
              </p>
              {activeFilterCount > 0 && (
                <div className="hidden flex-wrap gap-2 sm:flex">
                  {selectedTypes.map((type) => (
                    <Badge
                      key={type}
                      variant="secondary"
                      className="cursor-pointer gap-1"
                      onClick={() => toggleFilter(type, selectedTypes, setSelectedTypes)}
                    >
                      {type}
                      <X className="h-3 w-3" />
                    </Badge>
                  ))}
                  {selectedCategories.map((category) => (
                    <Badge
                      key={category}
                      variant="secondary"
                      className="cursor-pointer gap-1"
                      onClick={() =>
                        toggleFilter(category, selectedCategories, setSelectedCategories)
                      }
                    >
                      {category}
                      <X className="h-3 w-3" />
                    </Badge>
                  ))}
                  {selectedLocations.map((location) => (
                    <Badge
                      key={location}
                      variant="secondary"
                      className="cursor-pointer gap-1"
                      onClick={() =>
                        toggleFilter(location, selectedLocations, setSelectedLocations)
                      }
                    >
                      {location}
                      <X className="h-3 w-3" />
                    </Badge>
                  ))}
                </div>
              )}
            </div>

            {filteredJobs.length === 0 ? (
              <div className="flex flex-col items-center justify-center rounded-xl border border-border bg-card py-16 text-center">
                <Briefcase className="mb-4 h-12 w-12 text-muted-foreground" />
                <h3 className="mb-2 text-lg font-semibold text-foreground">No jobs found</h3>
                <p className="mb-4 text-sm text-muted-foreground">
                  Try adjusting your search or filters
                </p>
                <Button variant="outline" onClick={clearAllFilters}>
                  Clear all filters
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredJobs.map((job) => (
                  <JobListItem key={job.id} job={job} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      <Footer />
    </div>
  )
}

function JobListItem({ job }: { job: Job }) {
  return (
    <Link href={`/jobs/${job.id}`}>
      <div
        className={`group rounded-xl border p-5 transition-all hover:border-accent/50 hover:bg-card ${
          job.featured ? "border-accent/30 bg-card" : "border-border bg-card/50"
        }`}
      >
        <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div className="flex gap-4">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-secondary text-2xl">
              {job.logo}
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="font-semibold text-foreground group-hover:text-accent transition-colors">
                  {job.title}
                </h3>
                {job.featured && (
                  <Badge className="bg-accent/10 text-accent border-accent/20">Featured</Badge>
                )}
              </div>
              <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-muted-foreground">
                <span className="flex items-center gap-1">
                  <Building2 className="h-3.5 w-3.5" />
                  {job.company}
                </span>
                <span className="flex items-center gap-1">
                  <MapPin className="h-3.5 w-3.5" />
                  {job.location}
                </span>
                <span className="flex items-center gap-1">
                  <DollarSign className="h-3.5 w-3.5" />
                  {job.salary}
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="h-3.5 w-3.5" />
                  {job.postedAt}
                </span>
              </div>
              <div className="mt-3 flex flex-wrap gap-2">
                <Badge variant="outline" className="text-xs">
                  {job.type}
                </Badge>
                {job.tags.slice(0, 3).map((tag) => (
                  <Badge key={tag} variant="secondary" className="text-xs">
                    {tag}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
          <Button
            variant="outline"
            className="shrink-0 self-start opacity-0 transition-opacity group-hover:opacity-100"
          >
            View Job
          </Button>
        </div>
      </div>
    </Link>
  )
}
