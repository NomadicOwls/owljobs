"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card } from "@/components/ui/card"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import type { Job } from "@/lib/jobs-data"
import {
  ArrowLeft,
  MapPin,
  Briefcase,
  DollarSign,
  Clock,
  Building2,
  Users,
  Globe,
  Bookmark,
  Share2,
  CheckCircle2,
} from "lucide-react"

interface JobDetailClientProps {
  job: Job
}

export function JobDetailClient({ job }: JobDetailClientProps) {
  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="pt-24 pb-16">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back Button */}
          <Link
            href="/"
            className="mb-6 inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to all jobs
          </Link>

          {/* Job Header */}
          <div className="mb-8">
            <div className="flex flex-col gap-6 sm:flex-row sm:items-start sm:justify-between">
              <div className="flex items-start gap-4">
                <div className="flex h-16 w-16 items-center justify-center rounded-xl bg-secondary text-3xl">
                  {job.logo}
                </div>
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <h1 className="text-2xl font-bold text-foreground sm:text-3xl">
                      {job.title}
                    </h1>
                    {job.featured && (
                      <Badge className="bg-accent text-accent-foreground">
                        Featured
                      </Badge>
                    )}
                  </div>
                  <p className="mt-1 text-lg text-muted-foreground">{job.company}</p>
                </div>
              </div>

              <div className="flex gap-2">
                <Button variant="outline" size="icon" className="border-border">
                  <Bookmark className="h-4 w-4" />
                  <span className="sr-only">Save job</span>
                </Button>
                <Button variant="outline" size="icon" className="border-border">
                  <Share2 className="h-4 w-4" />
                  <span className="sr-only">Share job</span>
                </Button>
              </div>
            </div>

            {/* Job Meta */}
            <div className="mt-6 flex flex-wrap gap-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-1.5">
                <MapPin className="h-4 w-4" />
                {job.location}
              </div>
              <div className="flex items-center gap-1.5">
                <Briefcase className="h-4 w-4" />
                {job.type}
              </div>
              <div className="flex items-center gap-1.5">
                <DollarSign className="h-4 w-4" />
                {job.salary}
              </div>
              <div className="flex items-center gap-1.5">
                <Clock className="h-4 w-4" />
                Posted {job.postedAt}
              </div>
            </div>

            {/* Tags */}
            <div className="mt-4 flex flex-wrap gap-2">
              {job.tags.map((tag) => (
                <Badge
                  key={tag}
                  variant="secondary"
                  className="bg-secondary text-secondary-foreground"
                >
                  {tag}
                </Badge>
              ))}
            </div>

            {/* Apply Button */}
            <div className="mt-6">
              <Button
                size="lg"
                className="w-full bg-accent text-accent-foreground hover:bg-accent/90 sm:w-auto"
              >
                Apply for this position
              </Button>
            </div>
          </div>

          <div className="grid gap-8 lg:grid-cols-3">
            {/* Main Content */}
            <div className="lg:col-span-2">
              {/* Description */}
              <Card className="border-border bg-card p-6">
                <h2 className="text-lg font-semibold text-card-foreground">
                  About this role
                </h2>
                <p className="mt-4 leading-relaxed text-muted-foreground">
                  {job.description}
                </p>
              </Card>

              {/* Responsibilities */}
              <Card className="mt-6 border-border bg-card p-6">
                <h2 className="text-lg font-semibold text-card-foreground">
                  What you&apos;ll do
                </h2>
                <ul className="mt-4 space-y-3">
                  {job.responsibilities.map((item, index) => (
                    <li key={index} className="flex gap-3 text-muted-foreground">
                      <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-accent" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </Card>

              {/* Requirements */}
              <Card className="mt-6 border-border bg-card p-6">
                <h2 className="text-lg font-semibold text-card-foreground">
                  What we&apos;re looking for
                </h2>
                <ul className="mt-4 space-y-3">
                  {job.requirements.map((item, index) => (
                    <li key={index} className="flex gap-3 text-muted-foreground">
                      <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-accent" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </Card>

              {/* Benefits */}
              <Card className="mt-6 border-border bg-card p-6">
                <h2 className="text-lg font-semibold text-card-foreground">
                  Benefits & Perks
                </h2>
                <ul className="mt-4 space-y-3">
                  {job.benefits.map((item, index) => (
                    <li key={index} className="flex gap-3 text-muted-foreground">
                      <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-accent" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-1">
              <Card className="sticky top-24 border-border bg-card p-6">
                <h2 className="text-lg font-semibold text-card-foreground">
                  About {job.company}
                </h2>
                <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
                  {job.companyDescription}
                </p>

                <div className="mt-6 space-y-4">
                  <div className="flex items-center gap-3 text-sm">
                    <Building2 className="h-5 w-5 text-muted-foreground" />
                    <span className="text-muted-foreground">Company</span>
                    <span className="ml-auto font-medium text-foreground">
                      {job.company}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 text-sm">
                    <Users className="h-5 w-5 text-muted-foreground" />
                    <span className="text-muted-foreground">Size</span>
                    <span className="ml-auto font-medium text-foreground">
                      {job.companySize}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 text-sm">
                    <Globe className="h-5 w-5 text-muted-foreground" />
                    <span className="text-muted-foreground">Website</span>
                    <a
                      href={`https://${job.companyWebsite}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="ml-auto font-medium text-accent hover:underline"
                    >
                      {job.companyWebsite}
                    </a>
                  </div>
                </div>

                <div className="mt-6 border-t border-border pt-6">
                  <Button
                    className="w-full bg-accent text-accent-foreground hover:bg-accent/90"
                  >
                    Apply Now
                  </Button>
                  <p className="mt-3 text-center text-xs text-muted-foreground">
                    Applications are reviewed within 48 hours
                  </p>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
