import { notFound } from "next/navigation"
import { getJobById, jobs } from "@/lib/jobs-data"
import { JobDetailClient } from "./job-detail-client"

export function generateStaticParams() {
  return jobs.map((job) => ({
    id: String(job.id),
  }))
}

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const job = getJobById(Number(id))

  if (!job) {
    return {
      title: "Job Not Found - PrompterJobs",
    }
  }

  return {
    title: `${job.title} at ${job.company} - PrompterJobs`,
    description: job.description.slice(0, 160),
  }
}

export default async function JobPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const job = getJobById(Number(id))

  if (!job) {
    notFound()
  }

  return <JobDetailClient job={job} />
}
